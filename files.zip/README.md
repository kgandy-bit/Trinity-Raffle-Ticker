# Trinity 50/50 Raffle — Auto-Updating Ticker Image

Renders the current raffle total as a PNG on a schedule, so you can embed a
"live-ish" number in an email via a plain `<img>` tag. Email clients can't
run JavaScript or iframes, so this is the standard workaround: an image that
refreshes itself in the background at a stable URL.

## How it works
1. `render-ticker.js` fetches the current total from Givebutter's data
   endpoint and draws it onto a PNG.
2. A GitHub Action runs that script every ~20 minutes and publishes the
   image to GitHub Pages, giving you one unchanging URL that always shows
   a recent snapshot.
3. You put that URL in an `<img src="...">` tag inside your Constant
   Contact email.

## One-time setup

### 1. Find the Givebutter data endpoint
1. Open `https://live.givebutter.com/c/2025-5050-raffle-copy-rhkmgp` in Chrome.
2. DevTools (F12 or right-click → Inspect) → **Network** tab → filter to **Fetch/XHR**.
3. Reload the page.
4. Look for a request returning JSON with the raised amount (often something
   like `.../campaigns/...` or `.../transactions`). Click it → **Response** tab
   to confirm you see a number matching the live total.
5. Copy the full request URL.

### 2. Check the JSON shape
Once you have the URL, open it directly in a browser tab (if it's a public
GET endpoint, it'll just show JSON). Note which field holds the dollar
amount — `render-ticker.js`'s `extractTotal()` function tries a few common
names (`raised`, `amount_raised`, `total`, etc.) but you may need to add the
exact field name you see.

### 3. Push this repo to GitHub
```bash
git init
git add .
git commit -m "initial commit"
git remote add origin https://github.com/YOUR_ORG/YOUR_REPO.git
git push -u origin main
```

### 4. Add the endpoint as a repo secret
In your GitHub repo: **Settings → Secrets and variables → Actions → New
repository secret**
- Name: `GIVEBUTTER_DATA_URL`
- Value: the URL you found in step 1

### 5. Enable GitHub Pages
**Settings → Pages → Build and deployment → Source: "Deploy from a branch"
→ Branch: `gh-pages` / root.** (The Action creates this branch
automatically the first time it runs.)

### 6. Run it once manually
**Actions tab → "Update Raffle Ticker" → Run workflow.** Check the run logs;
if `extractTotal()` throws an error, it'll print the raw JSON payload so you
can see the real field name and fix it in `render-ticker.js`.

### 7. Get your image URL
Once Pages is live, your image will be at:
```
https://YOUR_ORG.github.io/YOUR_REPO/raffle-total.png
```

## Using it in Constant Contact

Paste this into a custom HTML block:

```html
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px; margin:0 auto; font-family:Arial, Helvetica, sans-serif;">
  <tr>
    <td align="center" style="padding: 24px;">
      <img src="https://YOUR_ORG.github.io/YOUR_REPO/raffle-total.png"
           alt="Current raffle total"
           width="600"
           style="max-width:100%; border-radius:8px; display:block;" />
      <p style="margin:16px 0 0; font-size:14px; color:#666;">
        <a href="https://live.givebutter.com/c/2025-5050-raffle-copy-rhkmgp"
           target="_blank" style="color:#0057a8;">
          Tap here for the real-time total →
        </a>
      </p>
    </td>
  </tr>
</table>
```

## Important limitations to set expectations with your team
- The image only updates as often as the GitHub Action runs (every ~20 min
  here) — it is **not** live-live.
- Some email clients (notably Outlook desktop) aggressively cache images,
  so a recipient who opens the email multiple times over several days may
  see a stale number until their cache clears. This is unavoidable with
  the image-embed approach.
- Always keep the "tap here for real-time total" link — it's the only way
  to guarantee someone sees the actual current number.
