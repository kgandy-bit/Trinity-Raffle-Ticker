/**
 * render-ticker.js
 *
 * Fetches the current raffle/campaign total from Givebutter and renders it
 * as a PNG image. Designed to be run on a schedule (e.g. GitHub Actions
 * cron every 15-30 min) so the output image, hosted at a stable URL, can
 * be embedded via <img> in an email (Constant Contact, etc.) and shows a
 * reasonably fresh number each time the email is opened.
 *
 * SETUP REQUIRED:
 *   1. Find your campaign's data endpoint (see instructions in chat / README.md).
 *   2. Set GIVEBUTTER_DATA_URL below (or via env var).
 *   3. Adjust `extractTotal()` to match the JSON shape you actually get back
 *      — Givebutter's exact response structure isn't something I can verify
 *      without live web access, so this function has a couple of common
 *      fallback paths but you may need to tweak it once you see real data.
 */

const fetch = require('node-fetch');
const { createCanvas } = require('canvas');
const fs = require('fs');
const path = require('path');

// ---- CONFIG ---------------------------------------------------------------

// TODO: replace with the JSON endpoint you find in Chrome DevTools > Network
const GIVEBUTTER_DATA_URL =
  process.env.GIVEBUTTER_DATA_URL ||
  'https://REPLACE_ME_WITH_REAL_ENDPOINT';

const OUTPUT_PATH = path.join(__dirname, 'output', 'raffle-total.png');

// ---- HELPERS ----------------------------------------------------------------

/**
 * Pull the dollar total out of whatever JSON Givebutter returns.
 * Tries a few common field names; log the raw payload once and adjust
 * this if none of these match your actual response.
 */
function extractTotal(data) {
  const candidates = [
    data?.raised,
    data?.amount_raised,
    data?.total,
    data?.campaign?.raised,
    data?.campaign?.amount_raised,
    data?.data?.raised,
  ];
  const found = candidates.find((v) => typeof v === 'number');
  if (found === undefined) {
    throw new Error(
      'Could not find a numeric total in the response. ' +
        'Raw payload was: ' + JSON.stringify(data).slice(0, 500)
    );
  }
  return found;
}

function formatCurrency(amount) {
  return amount.toLocaleString('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0,
  });
}

function drawTickerImage(totalText, { asOfText }) {
  const width = 600;
  const height = 260;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');

  // Background
  ctx.fillStyle = '#f4f4f4';
  ctx.fillRect(0, 0, width, height);

  // Rounded card
  const pad = 16;
  ctx.fillStyle = '#ffffff';
  roundRect(ctx, pad, pad, width - pad * 2, height - pad * 2, 12);
  ctx.fill();

  // Label
  ctx.fillStyle = '#444444';
  ctx.font = '20px Arial, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('Trinity Collegiate School 50/50 Raffle', width / 2, 60);

  // Total
  ctx.fillStyle = '#0057a8';
  ctx.font = 'bold 56px Arial, sans-serif';
  ctx.fillText(totalText, width / 2, 140);

  // "Current Jackpot" caption
  ctx.fillStyle = '#666666';
  ctx.font = '16px Arial, sans-serif';
  ctx.fillText('Current Jackpot', width / 2, 170);

  // Timestamp
  ctx.fillStyle = '#999999';
  ctx.font = '13px Arial, sans-serif';
  ctx.fillText(asOfText, width / 2, height - 28);

  return canvas.toBuffer('image/png');
}

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

// ---- MAIN -------------------------------------------------------------------

async function main() {
  if (GIVEBUTTER_DATA_URL.includes('REPLACE_ME')) {
    console.error(
      'ERROR: Set GIVEBUTTER_DATA_URL to the real endpoint before running.\n' +
        'Find it via Chrome DevTools > Network > Fetch/XHR on the raffle page.'
    );
    process.exit(1);
  }

  const res = await fetch(GIVEBUTTER_DATA_URL, {
    headers: { 'User-Agent': 'Mozilla/5.0 (compatible; TrinityRaffleTicker/1.0)' },
  });

  if (!res.ok) {
    throw new Error(`Request failed: ${res.status} ${res.statusText}`);
  }

  const data = await res.json();
  const total = extractTotal(data);
  const totalText = formatCurrency(total);

  const now = new Date();
  const asOfText = `Updated ${now.toLocaleString('en-US', {
    timeZone: 'America/New_York',
    dateStyle: 'medium',
    timeStyle: 'short',
  })} ET`;

  const png = drawTickerImage(totalText, { asOfText });

  fs.mkdirSync(path.dirname(OUTPUT_PATH), { recursive: true });
  fs.writeFileSync(OUTPUT_PATH, png);

  console.log(`Wrote ${OUTPUT_PATH} — total: ${totalText} (${asOfText})`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
